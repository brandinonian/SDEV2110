let n = 10;
let x = 10;

// for loop
console.log('For Loop');

for(let i = 1; i <= 5; i++) {
    n += i;
    console.log(n);
}

// while loop
let i = 1;

console.log('While Loop');

while(i <= 5) {
    x += i;
    console.log(x);
    i++;
}